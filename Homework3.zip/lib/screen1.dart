import 'package:flutter/material.dart';

class Screen1 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('First Screen'),
        backgroundColor: Colors.teal,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Hello from Screen 1',
              style: TextStyle(color: Colors.teal, fontSize: 18.0),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/screen2',
                    arguments: 'Data sent from First Screen');
              },
              child: Text('Move to Second Screen'),
            ),
            SizedBox(height: 20.0),
            Container(
              width: 120,
              height: 120,
              color: Colors.orange,
            ),
            SizedBox(height: 20.0),
            Text(
              'Simple Text Component',
              style: TextStyle(color: Colors.teal, fontSize: 16.0),
            ),
            SizedBox(height: 20.0),
            FlutterLogo(size: 60.0),
            // Add more widgets as needed...
          ],
        ),
      ),
    );
  }
}
