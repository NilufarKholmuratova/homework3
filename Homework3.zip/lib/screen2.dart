import 'package:flutter/material.dart';

class Screen2 extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    String dataFromScreen1 =
        ModalRoute.of(context)?.settings.arguments as String;

    return Scaffold(
      appBar: AppBar(
        title: Text('Second Screen'),
        backgroundColor: Colors.blue,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Data received from First Screen: $dataFromScreen1',
              style: TextStyle(color: Colors.blue, fontSize: 18.0),
            ),
            ElevatedButton(
              onPressed: () {
                // Perform an action
              },
              child: Text('Click Me'),
            ),
            SizedBox(height: 20.0),
            Container(
              width: 150,
              height: 150,
              color: Colors.yellow,
            ),
            SizedBox(height: 20.0),
            Icon(Icons.star, color: Colors.yellow, size: 40.0),
            SizedBox(height: 20.0),
            Text(
              'Another Text Component',
              style: TextStyle(color: Colors.blue, fontSize: 16.0),
            ),
            // Add more widgets as needed...
          ],
        ),
      ),
    );
  }
}
